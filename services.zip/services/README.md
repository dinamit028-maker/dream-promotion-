# services — תמונות ברירת מחדל

תבנית: שירותים. צבעים: כחול כהה `#0f3b66`, טורקיז `#0f766e`. אור יום קריר.

| קובץ | slot | גודל |
|---|---|---|
| services-hero-wide.webp | hero (wide, textSafe right) | 1672×941 |
| services-hero-wide-2.webp | hero (wide, textSafe right) | 1672×941 |
| services-hero-vertical.webp | hero (vertical) | 1024×1536 |
| services-image-text.webp | imageText (4:3) | 1255×941 |
| services-cat-packages.webp | collection: packages | 1080×1080 |
| services-gallery-1.webp | gallery (4:5) | 1024×1280 |
| services-gallery-2.webp | gallery (4:5) | 1024×1280 |
| services-gallery-3.webp | gallery (4:5) | 1024×1280 |

- נוקו: סמל על מכסה המחשב הנייד (hero-wide-2, image-text).
- WebP באיכות 82. מטא-דאטה מלאה ב-`kit-images.json`.
