# retail — תמונות ברירת מחדל

תבנית: קמעונאות. צבעים: כתום שרוף `#b3420d` ושחור. אור חם.

| קובץ | slot | גודל |
|---|---|---|
| retail-hero-wide.webp | hero | 1672×941 |
| retail-hero-wide-2.webp | hero | 1672×941 |
| retail-hero-vertical.webp | hero | 1024×1536 |
| retail-image-text.webp | imageText | 1255×941 |
| retail-cat-new.webp | collection (new) | 1080×1080 |
| retail-cat-sale.webp | collection (sale) | 1080×1080 |
| retail-cat-recommended.webp | collection (recommended) | 1080×1080 |
| retail-gallery-1.webp | gallery | 1024×1280 |
| retail-gallery-2.webp | gallery | 1024×1280 |
| retail-gallery-3.webp | gallery | 1024×1280 |

- נוקו: סימונים דמויי טקסט על שדרות ספרים וקופסה במדף (hero-wide).
- WebP באיכות 82. מטא-דאטה מלאה ב-`kit-images.json`.
