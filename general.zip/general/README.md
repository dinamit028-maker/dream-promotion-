# general — תמונות ברירת מחדל

תבנית: כללי. צבעים: כחול `#2f5d8a` ואפור. אור יום מעונן ורך.

| קובץ | slot | גודל |
|---|---|---|
| general-hero-wide.webp | hero | 1672×940 |
| general-hero-wide-2.webp | hero | 1672×941 |
| general-hero-vertical.webp | hero | 1024×1536 |
| general-image-text.webp | imageText | 1255×941 |
| general-cat-new.webp | collection (new) | 1080×1080 |
| general-cat-sale.webp | collection (sale) | 1080×1080 |
| general-gallery-1.webp | gallery | 1024×1280 |
| general-gallery-2.webp | gallery | 1024×1280 |
| general-gallery-3.webp | gallery | 1024×1280 |

- cat-sale נחתכה כך שהשרפרף כמעט לא נראה (דמיון לשרפרף מעצבים).
- hero-wide-2 הוחלפה בספסל עץ פשוט במקום ספסל מתכת שדמה לעיצוב מוכר.
- WebP באיכות 82. מטא-דאטה מלאה ב-`kit-images.json`.
