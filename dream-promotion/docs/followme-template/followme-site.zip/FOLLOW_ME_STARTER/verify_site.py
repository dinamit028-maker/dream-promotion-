from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import json, subprocess, hashlib, csv
from PIL import Image

ROOT=Path(__file__).resolve().parent
DIST=ROOT/'dist'
errors=[]
class Page(HTMLParser):
    def __init__(self):super().__init__();self.ids=[];self.refs=[];self.links=[];self.images=[];self.lang=False;self.rtl=False;self.title=False
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='html':self.lang=a.get('lang')=='he';self.rtl=a.get('dir')=='rtl'
        if tag=='title':self.title=True
        if a.get('id'):self.ids.append(a['id'])
        for key in ['aria-controls','aria-labelledby','for']:
            if key in a:self.refs.extend(a[key].split())
        for key in ['src','href']:
            if key in a:self.links.append((tag,key,a[key]))
        if tag in ['img','source'] and a.get('srcset'):
            self.links.extend((tag,'srcset',part.strip().split()[0]) for part in a['srcset'].split(','))
        if tag=='img':self.images.append(a)

pages={}
for file in DIST.rglob('*.html'):
    parsed=Page();parsed.feed(file.read_text());pages[file]=parsed
    if not parsed.lang or not parsed.rtl or not parsed.title:errors.append(f'{file}: missing Hebrew/RTL/title')
    if len(parsed.ids)!=len(set(parsed.ids)):errors.append(f'{file}: duplicate IDs')
    for ref in parsed.refs:
        if ref not in parsed.ids:errors.append(f'{file}: broken ARIA/label {ref}')
    for image in parsed.images:
        if not all(key in image for key in ['alt','width','height']):errors.append(f'{file}: incomplete image metadata')
        if not image.get('src'):errors.append(f'{file}: empty image source')

for file,parsed in pages.items():
    for tag,key,url in parsed.links:
        parts=urlsplit(url)
        if parts.scheme in ['http','https','mailto','tel','data']:continue
        if not url:errors.append(f'{file}: empty URL');continue
        target=(file.parent/unquote(parts.path)).resolve() if parts.path else file
        if target.is_dir():target=target/'index.html'
        if not target.exists():errors.append(f'{file}: missing target {url}');continue
        if parts.fragment:
            other=pages.get(target)
            if not other or parts.fragment not in other.ids:errors.append(f'{file}: missing anchor {url}')

manifest=json.loads((DIST/'assets/image-manifest.json').read_text())
for asset in manifest:
    if not asset.get('src'):continue
    path=DIST/asset['src']
    with Image.open(path) as image:
        if image.size!=(asset['width'],asset['height']):errors.append(f'{asset["id"]}: wrong native dimensions')
    for variant in asset.get('variants',[]):
        with Image.open(DIST/variant['src']) as image:
            if image.width!=variant['width']:errors.append(f'{asset["id"]}: wrong srcset width')

js=subprocess.run(['node','--check',str(DIST/'assets/app.js')],text=True,capture_output=True)
if js.returncode:errors.append(js.stderr)
bags=json.loads((DIST/'assets/bags-manifest.json').read_text())
bag_images=[a for a in bags['images'] if a['kind']=='bag']
site_images=[a for a in bags['images'] if a['kind']=='site']
assert len(bag_images)==60 and len(site_images)==22
for category in bags['categories']:
    assert sum(a['category']==category['id'] for a in bag_images)==10
all_html='\n'.join(file.read_text() for file in pages)
for asset in bags['images']:
    path=DIST/asset['src']
    if hashlib.sha256(path.read_bytes()).hexdigest()!=asset['sha256']:errors.append(f'{asset["id"]}: imported original bytes changed')
    with Image.open(path) as image:
        if image.size!=(asset['width'],asset['height']):errors.append(f'{asset["id"]}: wrong imported dimensions')
    if asset['src'] not in all_html:errors.append(f'{asset["id"]}: uploaded asset not integrated into any page')
    for variant in asset['variants']:
        with Image.open(DIST/variant['src']) as image:
            if image.width!=variant['width']:errors.append(f'{asset["id"]}: wrong uploaded srcset width')
for asset in bag_images:
    if 'design='+asset['id'] not in all_html:errors.append(f'{asset["id"]}: missing inquiry link')
assert len(pages)==9
assert sum(a['status']=='ready' for a in manifest)==19
assert [a['id'] for a in manifest if a['status']=='missing']==['020','021','022','023']
asset_rows=list(csv.DictReader((ROOT/'handoff/ASSET_MAP.csv').open(encoding='utf-8-sig')))
assert len(asset_rows)==106
for row in asset_rows:
    for key in ['site_path','source_path']:
        if row[key] and not (ROOT/row[key]).is_file():errors.append(f'{row["asset_id"]}: missing handoff {key}')
    if row['source_path'] and hashlib.sha256((ROOT/row['source_path']).read_bytes()).hexdigest()!=row['sha256']:
        errors.append(f'{row["asset_id"]}: handoff source checksum mismatch')
assert len(list((ROOT/'source-images/follow-me').glob('*.png')))==19
guide=Page();guide_file=ROOT/'handoff/IMAGE_CATALOG.html';guide.feed(guide_file.read_text())
for tag,key,url in guide.links:
    path=urlsplit(url).path
    if path and not (guide_file.parent/path).resolve().exists():errors.append(f'Image catalog: missing {url}')
for doc in ['README.md','CLAUDE_START_HERE.md','SITE_BLUEPRINT.md','PENDING_ITEMS.md']:
    if not (ROOT/doc).is_file():errors.append(f'Missing handoff document: {doc}')
summary={'status':'failed' if errors else 'passed','htmlPages':len(pages),'imageEntries':len(manifest),'readyImages':19,'uploadedImages':82,'catalogDesigns':60,'categoryCounts':{c['id']:sum(a['category']==c['id'] for a in bag_images) for c in bags['categories']},'desktopSource':1,'missingImages':['020','021','022','023'],'checks':['internal links and anchors','Hebrew / RTL / page titles','unique IDs and ARIA / form label references','local image and srcset file existence','image dimensions','JavaScript syntax','all 82 uploaded images integrated','original uploaded file checksums preserved','all 60 designs have inquiry links','6 categories with 10 designs each'],'browserVisualQA':'not performed: supported control-browser capability unavailable','errors':errors}
summary['checks']+=['all 19 generated PNG originals included','all 106 asset-map rows have valid files or explicit missing status','handoff source checksums','visual asset catalog links','developer handoff documents included']
(ROOT/'VALIDATION.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False))
if errors:raise SystemExit(1)
