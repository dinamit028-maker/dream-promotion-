"""Import the user's artwork without changing source bytes or filenames."""
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
from io import BytesIO
import argparse, hashlib, json
from PIL import Image

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--zip',required=True,type=Path)
args=parser.parse_args()
out=ROOT/'dist/images/bags-3d'
thumbs=out/'thumbs'
thumbs.mkdir(parents=True,exist_ok=True)
CATEGORIES=[
 ('handles','חבל וסרט',1,10,'site-03'),
 ('diecut','ידית חתוכה',11,20,'site-04'),
 ('paper','קראפט ונייר',21,30,'site-05'),
 ('boxes','קופסאות קשיחות',31,40,'site-06'),
 ('fabric','בד וטקסטיל',41,50,'site-07'),
 ('special','עיצובים מיוחדים',51,60,'site-08'),
]
SITE_ALTS=[
 'מבחר שקיות מעוצבות בגוונים שונים', 'שקיות מעוצבות בקומפוזיציה אנכית',
 'שקיות עם ידיות חבל וסרט', 'שקיות שחורה ולבנה עם ידית חתוכה',
 'שקיות קראפט חומות', 'קופסה מגנטית וקופסת מגירה',
 'תיק בד ושקיק טקסטיל', 'שקית שקופה ושקית במראה הולוגרפי',
 'מניפת חומרים ודוגמת שקית', 'תכנון אריזה ודוגמת שקית כחולה',
 'המחשת תהליך ייצור של שקיות', 'המחשת אריזות בתוך קרטונים להובלה',
 'גימור זהוב על רקע שחור', 'הבלטה בגוון טבעי', 'גימור שחור על שחור',
 'גימור במראה הולוגרפי', 'גימור זהוב על רקע בורדו',
 'מבחר סוגי ידיות', 'מבחר שקיות בסידור תצוגה',
 'שקיות וקופסאות בסביבת תצוגה', 'שקיות שחורות בתאורה כהה',
 'שלוש שקיות שחורות בקומפוזיציה מרחפת',
]
images=[]
seen=set()
with ZipFile(args.zip) as archive:
 for entry in sorted(archive.infolist(),key=lambda i:i.filename):
  if entry.is_dir():continue
  name=PurePosixPath(entry.filename)
  if name.is_absolute() or '..' in name.parts or name.suffix.lower()!='.webp':raise ValueError(entry.filename)
  if name.name in seen:raise ValueError('Duplicate filename '+name.name)
  seen.add(name.name)
  content=archive.read(entry)
  id=name.stem
  number=int(id.split('-')[1])
  kind=id.split('-')[0]
  category=next((c for c in CATEGORIES if c[2]<=number<=c[3]),None) if kind=='bag' else None
  if kind not in ['bag','site']:raise ValueError(name.name)
  with Image.open(BytesIO(content)) as image:
   image.load();width,height=image.size
   variants=[]
   for size in [360,640]:
    if size>=width:continue
    thumb=image.convert('RGB').resize((size,round(height*size/width)),Image.Resampling.LANCZOS)
    target=thumbs/f'{id}-{size}w.webp'
    thumb.save(target,'WEBP',quality=86,method=6)
    variants.append({'src':str(target.relative_to(ROOT/'dist')),'width':size})
  target=out/name.name
  target.write_bytes(content)
  variants.append({'src':str(target.relative_to(ROOT/'dist')),'width':width})
  images.append({'id':id,'filename':name.name,'src':str(target.relative_to(ROOT/'dist')),'width':width,'height':height,'variants':variants,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest(),'sourceType':'uploadedIllustration','sourceArchive':'bags-3d-images.zip','status':'ready','kind':kind,'category':category[0] if category else None,'categoryLabel':category[1] if category else None,'alt':f'דגם {id} — עיצוב אריזה להמחשה, {category[1]}' if category else SITE_ALTS[number-1]+' — להמחשה'})
assert sum(i['kind']=='bag' for i in images)==60
assert sum(i['kind']=='site' for i in images)==22
manifest={'sourceArchive':'bags-3d-images.zip','sourceUnchanged':True,'categories':[{'id':c[0],'label':c[1],'first':c[2],'last':c[3],'image':c[4]} for c in CATEGORIES],'images':images}
(ROOT/'dist/assets/bags-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'catalogDesigns':60,'siteImages':22,'originalBytesPreserved':True,'categories':6}))
