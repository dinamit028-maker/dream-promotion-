from pathlib import Path
import json
from PIL import Image

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source-images/follow-me'
OUT = ROOT / 'dist/images/follow-me'
OUT.mkdir(parents=True, exist_ok=True)

ASSETS = [
 (1,'home-hero-desktop','0cdba191-5191-42fc-82c7-62302c227bfd','שקיות, אריזה, מחשב ובגד מקופל על משטח אבן בהיר',['home']),
 (2,'home-hero-mobile','db6954db-dc78-4d5a-9d14-d5715d87e112','שקית שמנת, אריזה וטלפון בקומפוזיציה אנכית',['home']),
 (3,'shop-card','f8a45cc1-92c8-4381-807c-be790f903d1b','בגדים בגווני שמנת ובז׳ על מתלה',['home','shop']),
 (4,'sourcing-card','3f99887d-8dfa-434c-bd93-b6c9b022df1c','דוגמאות מוצרים וחומרים בסביבת עבודה',['home','sourcing']),
 (5,'packaging-card','bc8975c8-df49-48e2-b160-73ddb607bc86','שקיות שמנת וקופסה בירוק זית כהה',['home','packaging']),
 (6,'dream-card','43ab32fa-494b-42e0-a7ca-3c8904361b32','מחשב עם ממשק Dream Promotion להמחשה',['home','dream']),
 (7,'esim-card','42427f8c-6f7f-4018-a734-4de533c1d490','טלפון המציג את שם Tasimla ליד מזוודה',['home','esim']),
 (8,'shop-hero','f67e0507-9008-4039-abe0-eb899c828f1b','מתלה קולקציה על רקע קיר שמנת',['shop']),
 (9,'sourcing-hero','039e1014-9999-4b2e-aba6-af69e2c429d8','דוגמאות מוצרים וכלי מדידה על שולחן',['sourcing']),
 (10,'packaging-hero','99d842f6-7564-4745-b58d-160b5d9f1a64','משפחת שקיות וקופסאות על משטח אבן',['home','packaging']),
 (11,'dream-hero','a140ceee-a7f9-4af7-86b8-9085fad0e54d','מחשב עם שם Dream Promotion וטלפון בפינת עבודה',['home','dream']),
 (12,'esim-hero','b6415c53-42a7-4330-9b61-dddd29359e52','טלפון Tasimla ומזוודה בטרמינל מואר',['home','esim']),
 (13,'bag-rope','a74a6b51-7806-4b67-953b-4054ce224721','שלוש שקיות עם ידיות חבל וסרט סאטן',['home','packaging']),
 (14,'bag-diecut','faf1eaad-92ec-4a0c-a7fa-3d7a51f0c388','שתי שקיות עם ידית חתוכה בקרטון',['home','packaging']),
 (15,'bag-kraft','51c19440-8928-4e76-9afd-30572f8a9337','שלוש שקיות קראפט חומות עם ידיות נייר',['home','packaging']),
 (16,'rigid-boxes','a31630b6-1812-4cb3-a755-be5d693f0b71','קופסה מגנטית פתוחה וקופסת מגירה בשמנת',['home','packaging']),
 (17,'product-samples','cf1c4dfb-b9b7-4e87-a6c8-9c27fc6ad345','ידיים בוחנות דוגמאות בד ונייר',['home','sourcing']),
 (18,'quality-inspection','ac9fec35-e01a-4da9-b062-4d37d431732f','בדיקת מידות של קופסה בעזרת כלי מדידה',['home','sourcing']),
 (19,'business-travel','adfb02a7-8d00-4326-82a4-4d1f159fcade','מחברת דוגמאות וטלפון ליד מזוודה בטרקלין',['about','sourcing']),
]

manifest=[]
for number,slug,uid,alt,pages in ASSETS:
    source=SOURCE/f'fm-{number:03}-{slug}.png'
    if not source.is_file():raise FileNotFoundError(source)
    name=f'fm-{number:03}-{slug}'
    with Image.open(source) as original:
        image=original.convert('RGB')
        width,height=image.size
        path=OUT/f'{name}.webp'
        image.save(path,'WEBP',quality=87,method=6)
        variants=[]
        for size in (480,768,1200):
            if size>=width:continue
            thumb=image.resize((size,round(height*size/width)),Image.Resampling.LANCZOS)
            variant=OUT/f'{name}-{size}w.webp'
            thumb.save(variant,'WEBP',quality=85,method=6)
            variants.append({'src':str(variant.relative_to(ROOT/'dist')),'width':size})
        variants.append({'src':str(path.relative_to(ROOT/'dist')),'width':width})
        manifest.append({'id':f'{number:03}','src':str(path.relative_to(ROOT/'dist')),'width':width,'height':height,'alt':alt,'sourceType':'generatedIllustration','status':'ready','usedOn':pages,'focalPoint':'center','bytes':path.stat().st_size,'variants':variants})

source=SOURCE/'fm-020-tasimla-desktop-source.jpg'
with Image.open(source) as original:
    image=original.convert('RGB')
    path=OUT/'fm-020-tasimla-desktop-source.webp'
    image.save(path,'WEBP',lossless=True,method=6)
    manifest.append({'id':'020-desktop-source','src':str(path.relative_to(ROOT/'dist')),'width':image.width,'height':image.height,'alt':'צילום אמיתי של עמוד הבית של Tasimla בתצוגת מחשב','sourceType':'actualScreenshot','status':'source-only','usedOn':['esim'],'capturedAt':'2026-10-17','variants':[]})

for number,slug,kind,alt in [(20,'tasimla-mobile','actualScreenshot','צילום Tasimla במובייל'),(21,'dream-desktop','actualScreenshot','צילום Dream Promotion במחשב'),(22,'dream-mobile','actualScreenshot','צילום Dream Promotion במובייל'),(23,'aviv-portrait','actualPortrait','צילום אמיתי של אביב ישראל')]:
    manifest.append({'id':f'{number:03}','src':None,'expectedFilename':f'fm-{number:03}-{slug}.webp','sourceType':kind,'status':'missing','alt':alt,'variants':[]})
(ROOT/'dist/assets').mkdir(exist_ok=True)
(ROOT/'dist/assets/image-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'ready':19,'desktopSource':1,'missing':[20,21,22,23],'optimizedImageFiles':len(list(OUT.iterdir())),'totalBytes':sum(p.stat().st_size for p in OUT.iterdir())}))
