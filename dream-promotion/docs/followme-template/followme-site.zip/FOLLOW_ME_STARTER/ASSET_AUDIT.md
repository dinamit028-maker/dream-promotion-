# בדיקת נכסי התמונות — Follow Me

19 תמונות המחשה מוכנות, מקור צילום מסך אחד לדסקטופ וארבעה נכסים אמיתיים ממתינים.

## תיקונים שבוצעו

- נבחרה גרסת 006 המעודכנת, עם השם Dream Promotion.
- הוחל המיתוג המבוקש גם ב־011; 007 ו־012 מציגות את שם Tasimla.
- סומנו בנפרד מסכים להמחשה וצילום Tasimla האמיתי.
- צילום 020 לא סומן כמובייל: נשמר תחת שם desktop-source.
- נשמרו מידות המקור. לא בוצעה הגדלה כדי להעמיד פנים שהמקור הוא 2048 פיקסלים.
- נוצרו קובצי WebP ונגזרות קטנות לטעינה רספונסיבית.
- המניפסט מחזיק שמות קבועים, מידות, alt, סוג מקור וסטטוס.

## רשימת נכסים נוכחית

| מס׳ | קובץ / נכס צפוי | מידות מקור | סטטוס |
|---|---|---|---|
| 001 | fm-001-home-hero-desktop.webp | 1672×941 | ready |
| 002 | fm-002-home-hero-mobile.webp | 1122×1402 | ready |
| 003 | fm-003-shop-card.webp | 1448×1086 | ready |
| 004 | fm-004-sourcing-card.webp | 1448×1086 | ready |
| 005 | fm-005-packaging-card.webp | 1448×1086 | ready |
| 006 | fm-006-dream-card.webp | 1448×1086 | ready |
| 007 | fm-007-esim-card.webp | 1448×1086 | ready |
| 008 | fm-008-shop-hero.webp | 1672×941 | ready |
| 009 | fm-009-sourcing-hero.webp | 1672×941 | ready |
| 010 | fm-010-packaging-hero.webp | 1672×941 | ready |
| 011 | fm-011-dream-hero.webp | 1672×941 | ready |
| 012 | fm-012-esim-hero.webp | 1672×941 | ready |
| 013 | fm-013-bag-rope.webp | 1122×1402 | ready |
| 014 | fm-014-bag-diecut.webp | 1122×1402 | ready |
| 015 | fm-015-bag-kraft.webp | 1122×1402 | ready |
| 016 | fm-016-rigid-boxes.webp | 1122×1402 | ready |
| 017 | fm-017-product-samples.webp | 1448×1086 | ready |
| 018 | fm-018-quality-inspection.webp | 1448×1086 | ready |
| 019 | fm-019-business-travel.webp | 1448×1086 | ready |
| 020-desktop-source | fm-020-tasimla-desktop-source.webp | 1348×926 | source-only |
| 020 | fm-020-tasimla-mobile.webp | ממתין למקור | missing |
| 021 | fm-021-dream-desktop.webp | ממתין למקור | missing |
| 022 | fm-022-dream-mobile.webp | ממתין למקור | missing |
| 023 | fm-023-aviv-portrait.webp | ממתין למקור | missing |

## דגשים

הגרסאות שהתקבלו מהמחולל שומרות כמעט בדיוק על יחסי התמונה המבוקשים, אך לא על כל מידות הפיקסלים שהוגדרו בתוכנית המקורית. המניפסט וקוד האתר משתמשים במידות האמיתיות.

תמונות עם שולחן, מפעל, בגדים או דוגמאות אריזה הן המחשה, ואין לתאר אותן כתיעוד אישי, כהוכחת ביצוע או כמלאי זמין.

הצילום האמיתי של Tasimla נשמר בצבעיו המקוריים. צילומי Dream ודיוקן אביב לא הומצאו.

19 קובצי המקור הגולמיים צורפו בתיקיית source-images/follow-me בשמות מסודרים. החבילה כוללת גם נגזרות לשימוש באתר. מפת השימוש המעודכנת וקטלוג חזותי נמצאים בתיקיית handoff. נכסים חלופיים נשמרו גם כשאינם בשימוש בתבנית הנוכחית.

## עדכון — קובץ השקיות שהעלה המשתמש

נוספו 82 תמונות מהקובץ bags-3d-images.zip: שישים דגמים ו־22 תמונות אתר. קובצי המקור נשמרו בשמותיהם ובבתיהם המקוריים; סכומי SHA-256 נבדקו. כל 82 התמונות ממופות ומשולבות בעמודים. מיפוי מלא ב־BAGS_INTEGRATION.md וב־dist/assets/bags-manifest.json.
