(() => {
  'use strict';
  const menu = document.querySelector('.menu-toggle');
  const nav = document.getElementById('main-nav');
  menu?.addEventListener('click', () => {
    const open = menu.getAttribute('aria-expanded') !== 'true';
    menu.setAttribute('aria-expanded', String(open));
    menu.textContent = open ? 'סגירה ×' : 'תפריט ☰';
    nav?.classList.toggle('open', open);
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && nav?.classList.contains('open')) {
      menu.setAttribute('aria-expanded', 'false');
      menu.textContent = 'תפריט ☰';
      nav.classList.remove('open');
      menu.focus();
    }
  });
  const dialog = document.getElementById('review-dialog');
  document.querySelectorAll('[data-open-review]').forEach(button => button.addEventListener('click', () => {
    dialog.showModal();
    document.body.classList.add('dialog-open');
  }));
  document.querySelector('[data-close-review]')?.addEventListener('click', () => dialog.close());
  dialog?.addEventListener('close', () => document.body.classList.remove('dialog-open'));
  dialog?.addEventListener('click', event => { if (event.target === dialog) { const rect = dialog.getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close(); } });
  const catalogItems = [...document.querySelectorAll('.catalog-item')];
  if (catalogItems.length) {
    const filters = [...document.querySelectorAll('.catalog-filter')];
    const more = document.getElementById('catalog-more');
    const counter = document.getElementById('catalog-count');
    let selectedCategory = 'all';
    let visibleCount = 12;
    const categoryParam = new URLSearchParams(window.location.search).get('category');
    if (filters.some(filter => filter.dataset.category === categoryParam)) selectedCategory = categoryParam;
    function renderCatalog() {
      const matching = catalogItems.filter(item => selectedCategory === 'all' || item.dataset.category === selectedCategory);
      const visible = new Set(matching.slice(0, visibleCount));
      catalogItems.forEach(item => { item.hidden = !visible.has(item); });
      filters.forEach(filter => filter.setAttribute('aria-pressed', String(filter.dataset.category === selectedCategory)));
      more.hidden = matching.length <= visibleCount;
      counter.textContent = `מוצגים ${Math.min(visibleCount, matching.length)} מתוך ${matching.length} דגמים`;
    }
    filters.forEach(filter => filter.addEventListener('click', () => {
      selectedCategory = filter.dataset.category;
      visibleCount = 12;
      renderCatalog();
    }));
    more.addEventListener('click', () => { visibleCount += 12; renderCatalog(); });
    renderCatalog();
    const catalogDialog = document.getElementById('catalog-dialog');
    document.querySelectorAll('[data-enlarge]').forEach(button => button.addEventListener('click', () => {
      const photo = document.getElementById('catalog-dialog-image');
      photo.src = button.dataset.image;
      photo.alt = `דגם ${button.dataset.id} — ${button.dataset.label}, עיצוב להמחשה`;
      document.getElementById('catalog-dialog-title').textContent = 'דגם ' + button.dataset.id;
      document.getElementById('catalog-dialog-category').textContent = button.dataset.label;
      document.getElementById('catalog-dialog-link').href = button.dataset.quote;
      catalogDialog.showModal();
      document.body.classList.add('dialog-open');
    }));
    document.getElementById('catalog-dialog-close').addEventListener('click', () => catalogDialog.close());
    catalogDialog.addEventListener('close', () => document.body.classList.remove('dialog-open'));
    catalogDialog.addEventListener('click', event => {
      if (event.target !== catalogDialog) return;
      const bounds = catalogDialog.getBoundingClientRect();
      if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) catalogDialog.close();
    });
  }
  const form = document.getElementById('inquiry-form');
  if (!form) return;
  const service = document.getElementById('inquiry-service');
  const serviceParam = new URLSearchParams(window.location.search).get('service');
  if (serviceParam && [...service.options].some(option => option.value === serviceParam)) service.value = serviceParam;
  const designParam = new URLSearchParams(window.location.search).get('design');
  if (/^bag-\d{3}$/.test(designParam || '') && Number(designParam.slice(4)) >= 1 && Number(designParam.slice(4)) <= 60) {
    service.value = 'packaging';
    document.getElementById('inquiry-message').value = `אני מעוניין/ת בהצעת מחיר לאריזה בסגנון דגם ${designParam}.\nמידות המוצר: \nכמות משוערת: \nפרטים נוספים: `;
  }
  const output = document.getElementById('inquiry-output');
  const status = document.getElementById('inquiry-status');
  let draft = '';
  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const data = new FormData(form);
    const label = service.options[service.selectedIndex].text;
    draft = ['פנייה ל־Follow Me', 'תחום: ' + label, data.get('name') ? 'שם: ' + String(data.get('name')).trim() : '', data.get('contact') ? 'פרטי קשר: ' + String(data.get('contact')).trim() : '', '', String(data.get('message') || '').trim()].filter((line,index) => line || index === 4).join('\n');
    output.textContent = draft;
    document.getElementById('inquiry-actions').hidden = false;
    status.textContent = 'הטיוטה מוכנה להעתקה או להורדה. היא לא נשלחה.';
  });
  document.getElementById('copy-inquiry').addEventListener('click', async () => {
    if (!draft) return;
    try { await navigator.clipboard.writeText(draft); status.textContent = 'הטיוטה הועתקה. אפשר להדביק אותה בערוץ הקשר שייבחר.'; }
    catch { status.textContent = 'ההעתקה אינה זמינה בדפדפן הזה. אפשר להוריד את הטיוטה כקובץ.'; }
  });
  document.getElementById('download-inquiry').addEventListener('click', () => {
    if (!draft) return;
    const url = URL.createObjectURL(new Blob(['\uFEFF' + draft], {type:'text/plain;charset=utf-8'}));
    const link = document.createElement('a');
    link.href = url; link.download = 'follow-me-inquiry.txt';
    document.body.appendChild(link); link.click(); link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    status.textContent = 'נוצר קובץ של הטיוטה במכשיר. הפנייה לא נשלחה.';
  });
})();
