"""Create a portable developer handoff from the current built Site."""
from pathlib import Path
from html import escape
import csv, hashlib, json, zipfile, argparse

ROOT=Path(__file__).resolve().parent
DIST=ROOT/'dist'
HANDOFF=ROOT/'handoff'
HANDOFF.mkdir(exist_ok=True)
general=json.loads((DIST/'assets/image-manifest.json').read_text())
uploaded=json.loads((DIST/'assets/bags-manifest.json').read_text())['images']
pages={'home':'בית','shop':'חנות','sourcing':'סורסינג','packaging':'אריזות','catalog':'גלריה','dream':'Dream','esim':'Tasimla','about':'אודות','contact':'פנייה'}
html={page:(DIST/('index.html' if page=='home' else page+'/index.html')).read_text() for page in pages}
rows=[]
for item in general+uploaded:
    src=item.get('src')
    is_general=item in general
    family='follow-me' if is_general else 'uploaded-bags' if item['kind']=='bag' else 'uploaded-site'
    source=''
    if is_general and src:
        suffix='.jpg' if item['id']=='020-desktop-source' else '.png'
        source='source-images/follow-me/'+Path(src).stem+suffix
    elif src:source='dist/'+src
    uses=[page for page,content in html.items() if src and src in content]
    rows.append({'asset_id':item['id'],'family':family,'status':item.get('status','ready'),'usage':'active' if uses else 'pending' if not src else 'reserve','used_on':', '.join(uses),'site_path':'dist/'+src if src else '', 'source_path':source,'width':item.get('width',''),'height':item.get('height',''),'sha256':hashlib.sha256((ROOT/source).read_bytes()).hexdigest() if source else ''})

with (HANDOFF/'ASSET_MAP.csv').open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def card(item,row):
    src=item.get('src')
    if src:
        variants=item.get('variants',[])
        thumb=variants[0]['src'] if variants else src
        media=f'<a href="../dist/{escape(src,quote=True)}"><img loading="lazy" src="../dist/{escape(thumb,quote=True)}" width="{item["width"]}" height="{item["height"]}" alt="{escape(item.get("alt",""),quote=True)}"></a>'
    else:media='<div class="missing">ממתין למקור אמיתי</div>'
    status={'active':'בשימוש','reserve':'נשמר כחלופה','pending':'חסר להשלמה'}[row['usage']]
    uses=' · '.join(pages[p] for p in row['used_on'].split(', ') if p) or 'לא משובץ בתבנית הנוכחית'
    description=item.get('alt','')
    file=row['site_path'] or item.get('expectedFilename','')
    source_link=f'<a class="source" href="../{escape(row["source_path"],quote=True)}">פתיחת קובץ המקור ↗</a>' if row['source_path'] else ''
    return f'<article class="card">{media}<div class="copy"><span class="state {row["usage"]}">{status}</span><h3 dir="ltr">{escape(row["asset_id"])}</h3><p>{escape(description)}</p><p class="uses">עמודים: {escape(uses)}</p><code>{escape(file)}</code><small>{row["width"]} × {row["height"]}</small>{source_link}</div></article>'

groups=[('follow-me','תמונות Follow Me · מקור, מצב ושימוש'),('uploaded-site','22 תמונות האתר מהקובץ שהועלה'),('uploaded-bags','60 דגמי האריזות מהקובץ שהועלה')]
sections=''
for family,title in groups:
    selected=[(item,row) for item,row in zip(general+uploaded,rows) if row['family']==family]
    sections+=f'<section><h2>{title}</h2><div class="grid">'+''.join(card(item,row) for item,row in selected)+'</div></section>'
page='''<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Follow Me — קטלוג התמונות למסירה</title><style>
*{box-sizing:border-box}body{margin:0;background:#faf8f2;color:#252b20;font:16px/1.7 Arial,sans-serif}main{max-width:1350px;margin:auto;padding:35px 24px}h1{font-size:38px;line-height:1.2}h2{margin-top:55px;font-weight:500}h3{margin:10px 0 5px;text-align:right}a{color:#37462c;text-underline-offset:4px}.intro{max-width:850px}.actions{display:flex;flex-wrap:wrap;gap:12px;margin:25px 0}.actions a{padding:10px 18px;background:#37462c;color:white;text-decoration:none;border-radius:5px;min-height:44px}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:20px}.card{background:#fffefa;border:1px solid #d9ddce;border-radius:8px;overflow:hidden;min-width:0}.card img,.missing{width:100%;height:235px;object-fit:contain;background:#eee5d5}.missing{display:grid;place-items:center;color:#606657;font-size:14px}.copy{padding:16px}.copy p{margin:5px 0;font-size:13px}.copy .uses{font-size:12px;color:#606657}.state{font-size:11px;background:#e8ecdf;padding:4px 8px;border-radius:3px}.reserve{background:#eee5d5}.pending{background:#f3dfc9}code{direction:ltr;display:block;overflow-wrap:anywhere;font-size:10px;margin-top:9px}small{display:block;direction:ltr;text-align:right;font-size:11px;color:#606657}.source{display:inline-block;font-size:12px;margin-top:10px;padding-block:5px}a:focus-visible{outline:3px solid #8d6c20;outline-offset:3px}@media(max-width:1050px){.grid{grid-template-columns:repeat(3,minmax(0,1fr))}}@media(max-width:760px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}.card img,.missing{height:190px}}@media(max-width:460px){.grid{grid-template-columns:1fr}.card img,.missing{height:270px}}
</style></head><body><main><header><span>FOLLOW ME · DEVELOPER HANDOFF</span><h1>כל התמונות, במקום אחד.</h1><div class="intro"><p>19 תמונות שנוצרו לאתר, צילום Tasimla אמיתי ו־82 תמונות מהקובץ שהועלה. נשמרו גם תמונות חלופיות; ארבעה נכסים אמיתיים עדיין ממתינים להשלמה.</p><p>הקבצים המקוריים והנגזרות כלולים בתיקייה. לחיצה על תמונה פותחת את גרסת האתר; הקישור מתחתיה פותח את המקור.</p></div><div class="actions"><a href="../dist/index.html">לפתיחת ההדמיה העובדת ←</a><a href="ASSET_MAP.csv">למפת התמונות בקובץ CSV</a></div><p><strong>היררכיית האתר:</strong> Follow Me והצרכים המסחריים ← אביב והניסיון ← אריזות וסורסינג ← קולקציה ← Dream ו־Tasimla כמיזמים.</p></header>'''+sections+'''<footer><p>תמונות ההמחשה והשמות שבתוכן אינם אישור למלאי, למפרט או לרשימת לקוחות בפועל.</p></footer></main></body></html>'''
(HANDOFF/'IMAGE_CATALOG.html').write_text(page,encoding='utf-8')

parser=argparse.ArgumentParser();parser.add_argument('--zip',dest='output');args=parser.parse_args()
if args.output:
    target=Path(args.output).resolve();target.parent.mkdir(parents=True,exist_ok=True)
    directories=['dist','src','source-images','handoff']
    files=[p for directory in directories for p in (ROOT/directory).rglob('*') if p.is_file()]
    files += [p for p in ROOT.iterdir() if p.is_file() and (p.suffix in ['.md','.py'] or p.name in ['VALIDATION.json','requirements-dev.txt'])]
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for file in sorted(set(files)):archive.write(file,'FOLLOW_ME_STARTER/'+str(file.relative_to(ROOT)))
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        assert not any('/.git/' in n or '/.openai/' in n for n in archive.namelist())
    print(json.dumps({'zip':str(target),'files':len(set(files)),'bytes':target.stat().st_size,'assetRows':len(rows)}))
else:print(json.dumps({'assetRows':len(rows),'catalog':str(HANDOFF/'IMAGE_CATALOG.html')}))
